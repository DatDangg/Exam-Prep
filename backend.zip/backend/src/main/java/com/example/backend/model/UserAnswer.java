package com.example.backend.model;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Data
public class UserAnswer {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String questionId;
    private String userId;

    @Lob
    @Column(columnDefinition = "TEXT")
    private String answerJson;

    private boolean isCorrect;

    private Long completedExamId; // để liên kết về bài nộp
}
